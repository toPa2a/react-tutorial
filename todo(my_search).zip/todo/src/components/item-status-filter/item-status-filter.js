import React, {Component} from 'react';
import './item-status-filter.css';

export default class ItemStatusFilter extends Component {
    render() {
        const {onFilter, buttons} = this.props;
        
        return (
            <div className="btn-group float-right" role="group">
                {buttons.map((btn) => {
                    const classNames = 'btn ' + btn.className;
            
                    return <button type="button" className={classNames} onClick={() => onFilter(btn.filter, btn.id)} key={btn.id}>{btn.text}</button>
                })}
            </div>
        );
    }
}