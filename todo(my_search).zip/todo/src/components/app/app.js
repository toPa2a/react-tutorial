import React, {Component} from 'react';
import AppHeader from '../app-header';
import SearchPanel from '../search-panel';
import ItemStatusFilter from '../item-status-filter';
import TodoList from '../todo-list';
import ItemAddForm from '../item-add-form';
import './app.css';



export default class App extends Component {
    maxId = 100;
    
    state = {
        todoData: [
            this.createTodoItem('Drink Coffee'),
            this.createTodoItem('Make Awesome App'),
            this.createTodoItem('Have a Lunch')
        ],
        filteredData: [],
        searchString: '',
        filter: false,
        filterBtns: [
            {text: 'All', className: 'btn-info', id: 'b1', filter: false},
            {text: 'Active', className: 'btn-outline-secondary', id: 'b2', filter: {done: false}},
            {text: 'Done', className: 'btn-outline-secondary', id: 'b3', filter: {done: true}}
        ]
    };
    
    createTodoItem(label) {
        return {
            label,
            important: false,
            done: false,
            hidden: false,
            id: this.maxId++
        };
    }
    
    deleteItem = (id) => {
        this.setState(({todoData}) => {
            const idx = todoData.findIndex((el) => el.id === id);
            const newArray = [
                ...todoData.slice(0, idx), 
                ...todoData.slice(idx + 1)
            ];
            
            return {
                todoData: newArray,
                filteredData: this.returnFiltered()
            };
        });
    };
    
    addItem = (text) => {
        const newItem = this.createTodoItem(text);
        
        this.setState(({todoData}) => {
            const newArray = [
                ...todoData,
                newItem
            ];
            
            return {
                todoData: newArray,
                filteredData: this.returnFiltered()
            };
        });
    };
    
    returnFiltered = (filterData = {}) => {
        const {searchString} = ('searchString' in filterData) ? filterData : this.state;
        const {filter} = ('filter' in filterData) ? filterData : this.state;
        const {todoData} = this.state;
        let newArray;
        
        newArray = todoData.filter((item) => {
            const searchLower = searchString.toLowerCase();

            return item.label.toLowerCase().indexOf(searchLower) !== -1;
        });
        
        if (filter) {
            newArray = newArray.filter((item) => {
                const [key, value] = Object.entries(filter)[0];
                
                return item[key] === value;
            });
        }
        
        return newArray;
    };
    
    toggleProperty(arr, id, propName) {
        if (arr.length > 0) {
            const idx = arr.findIndex((el) => el.id === id);
            const oldItem = arr[idx];
            const newItem = {...oldItem, [propName]: !oldItem[propName]};

            return [
                ...arr.slice(0, idx),
                newItem,
                ...arr.slice(idx + 1)
            ];
        }
        
        return arr;
    }
    
    onToggleDone = (id) => {
        this.setState(({todoData, filteredData, searchString}) => {
            return {
                todoData: this.toggleProperty(todoData, id, 'done'),
                filteredData: this.toggleProperty(filteredData, id, 'done')
            }
        });
    };
    
    onToggleImportant = (id) => {
        this.setState(({todoData, filteredData}) => {
            return {
                todoData: this.toggleProperty(todoData, id, 'important'),
                filteredData: this.toggleProperty(filteredData, id, 'important')
            }
        });
    };
    
    onSearch = (search) => {
        this.setState(({filteredData, searchString, filter}) => {
            return {
                filteredData: this.returnFiltered({searchString: search}),
                searchString: search
            };
        });
    };
    
    onFilter = (filterValue, id) => {
        const newBtns = this.state.filterBtns.map((btn) => {
            return {...btn, className: (btn.id === id) ? 'btn-info' : 'btn-outline-secondary'};
        });
        
        this.setState(({filteredData, searchString, filter, filterBtns}) => {
            return {
                filteredData: this.returnFiltered({filter: filterValue}),
                filter: filterValue,
                filterBtns: newBtns
            };
        });
    };
    
    render() {
        const {todoData, filteredData, searchString, filter, filterBtns} = this.state;
        const toRender = (searchString.length > 0 || filter) ? filteredData : todoData;
        const doneCount = toRender.filter((el) => el.done).length;
        const todoCount = toRender.length - doneCount;
        
        return (
            <div className="todo-app">
                <AppHeader toDo={todoCount} done={doneCount} />
                <div className="top-panel d-flex">
                    <SearchPanel onSearch={this.onSearch} />
                    <ItemStatusFilter onFilter={this.onFilter} buttons={filterBtns} />
                </div>
                <TodoList 
                    todos={toRender} 
                    onDeleted={this.deleteItem}
                    onToggleImportant={this.onToggleImportant}
                    onToggleDone={this.onToggleDone} />
                <ItemAddForm onItemAdded={this.addItem} />
            </div>
        );
    };
};