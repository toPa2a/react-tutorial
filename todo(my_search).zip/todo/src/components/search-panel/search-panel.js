import React from 'react';
import './search-panel.css';

const SearchPanel = ({onSearch}) => {
    const onSearchChange = (e) => {
        onSearch(e.target.value);
    };
    
    return (
        <input type="text"
            className="form-control search-input"
            placeholder="type to search"
            onChange={onSearchChange} />
    );
};

export default SearchPanel;