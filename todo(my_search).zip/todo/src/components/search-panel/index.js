import SearchPanel from './search-panel';

export default SearchPanel;